#!/bin/bash

echo "192.168.1.10		portainer" >> "/etc/hosts"
echo "192.168.1.10		webdev" >> "/etc/hosts"
echo "192.168.1.10		gitlab" >> "/etc/hosts"
echo "192.168.1.10		jenkins" >> "/etc/hosts"
echo "192.168.1.10		sonarqube" >> "/etc/hosts"
echo "192.168.1.10		testlink" >> "/etc/hosts"
echo "192.168.1.10		phpmyadmin" >> "/etc/hosts"
echo "192.168.1.10		pgadmin" >> "/etc/hosts"
